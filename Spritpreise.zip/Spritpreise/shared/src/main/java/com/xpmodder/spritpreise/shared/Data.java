package com.xpmodder.spritpreise.shared;

import com.xpmodder.spritpreise.shared.html.HTMLParser;

import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;

public final class Data {

    public static String requestURL = "https://www.clever-tanken.de/tankstelle_liste?ort=Schortens&spritsorte=7&r=5";

    public static ArrayList<Tankstelle> tankstellen = new ArrayList<>();

    public static void refresh(Runnable toDoAfter){
        Data.tankstellen.clear();

        CompletableFuture.runAsync(()-> HTMLParser.getAndParse(requestURL)).thenRun(toDoAfter);
    }

}
