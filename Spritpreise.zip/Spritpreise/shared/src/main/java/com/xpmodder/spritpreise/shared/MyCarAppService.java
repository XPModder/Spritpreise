package com.xpmodder.spritpreise.shared;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.car.app.CarAppService;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.Session;
import androidx.car.app.model.*;
import androidx.car.app.validation.HostValidator;
import androidx.core.graphics.drawable.IconCompat;
import androidx.lifecycle.DefaultLifecycleObserver;
import com.xpmodder.spritpreise.shared.html.StringUtils;

import java.util.List;


public final class MyCarAppService extends CarAppService{


    @SuppressLint("PrivateResource")
    @NonNull
    @Override
    public HostValidator createHostValidator() {
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            return HostValidator.ALLOW_ALL_HOSTS_VALIDATOR;
        } else {
            return new HostValidator.Builder(getApplicationContext())
                    .addAllowedHosts(androidx.car.app.R.array.hosts_allowlist_sample)
                    .build();
        }
    }

    @NonNull
    @Override
    public Session onCreateSession() {
        return new Session() {
            @NonNull
            @Override
            public Screen onCreateScreen(@NonNull Intent intent) {
                return new PlaceListScreen(getCarContext());
            }
        };
    }


    public static class PlaceListScreen extends Screen implements DefaultLifecycleObserver {


        private Place getLocation(Tankstelle tankstelle){

            CarIcon icon = new CarIcon.Builder(IconCompat.createWithResource(getCarContext(), R.drawable.marker_icon)).build();
            PlaceMarker marker = new PlaceMarker.Builder().setIcon(icon, PlaceMarker.TYPE_IMAGE).build();

            try {

                Geocoder geocoder = new Geocoder(getCarContext());

                List<Address> addresses = geocoder.getFromLocationName(tankstelle.name + " " + tankstelle.address + ", " + tankstelle.city, 1);

                double lat = addresses.get(0).getLatitude();
                double lon = addresses.get(0).getLongitude();

                CarLocation location = CarLocation.create(lat, lon);

                return new Place.Builder(location).setMarker(marker).build();

            }
            catch (Exception ex){
                CarLocation location = CarLocation.create(0, 0);
                return new Place.Builder(location).setMarker(marker).build();
            }

        }

        protected PlaceListScreen(@NonNull CarContext carContext) {
            super(carContext);
            getLifecycle().addObserver(this);
            Data.refresh(this::invalidate);
        }

        @NonNull
        @Override
        public Template onGetTemplate() {

            ItemList.Builder listBuilder = new ItemList.Builder();

            for(Tankstelle tankstelle : Data.tankstellen){

                Place place = getLocation(tankstelle);

                Row.Builder builder = new Row.Builder();
                builder.setTitle(StringUtils.ScriptsHtmlToString(tankstelle.price));
                builder.addText(tankstelle.name);
                builder.addText(tankstelle.address + " " + tankstelle.city);
                builder.setMetadata(new Metadata.Builder().setPlace(place).build());
                builder.setBrowsable(true);
                builder.setOnClickListener(() -> {
                    Intent intent = new Intent(CarContext.ACTION_NAVIGATE, Uri.parse("geo:0,0?q=" + Uri.encode(tankstelle.name + " " + tankstelle.address + ", " + tankstelle.city)));
                    getCarContext().startCarApp(intent);
                });
                listBuilder.addItem(builder.build());

            }

            Row.Builder builder = new Row.Builder();
            builder.setTitle(getCarContext().getText(R.string.refresh_title));
            builder.addText(getCarContext().getText(R.string.refresh_line));
            builder.setBrowsable(true);
            builder.setOnClickListener(() -> {
                Data.tankstellen.clear();
                invalidate();
                Data.refresh(this::invalidate);
            });
            listBuilder.addItem(builder.build());


            PlaceListMapTemplate.Builder mapBuilder = new PlaceListMapTemplate.Builder();
            mapBuilder.setTitle(getCarContext().getText(R.string.stations_title));
            mapBuilder.setHeaderAction(Action.APP_ICON);
            mapBuilder.setCurrentLocationEnabled(true);

            if(Data.tankstellen.isEmpty()){
                Log.i("TestTag", "Data empty!");
                mapBuilder.setItemList( new ItemList.Builder().build());
                return mapBuilder.setLoading(true).build();
            }
            else{
                mapBuilder.setItemList( new ItemList.Builder().build());
                mapBuilder.setItemList(listBuilder.build());
                return mapBuilder.build();
            }

        }
    }

}
